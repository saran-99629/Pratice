var sidenav = document.querySelector(".side-navbar");



function shownavbar(){
    sidenav.style.left="0"
}

function closenav(){
    sidenav.style.left='-60%'
}