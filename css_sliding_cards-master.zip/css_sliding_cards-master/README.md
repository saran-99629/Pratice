# Stunning HTML & CSS Card Animation

![Thumbnail](thumbnail.png)

Full tutorial here: https://www.youtube.com/watch?v=45mnmy2JUl0

Sliding images (not in repo): https://wirestock.io/james591
